# AI Knowledge Assistant (RAG-Based)

## Overview
A simple Retrieval-Augmented Generation (RAG) project that:
- Reads PDF documents
- Creates embeddings using Sentence Transformers
- Stores vectors in FAISS
- Retrieves relevant content using semantic search
- Uses OpenAI GPT to generate answers

## Installation

pip install -r requirements.txt

## Usage

1. Put a PDF in data/company_handbook.pdf
2. Add your OpenAI API key in main.py
3. Run:

python main.py

## Technologies
- Python
- OpenAI
- FAISS
- Sentence Transformers
- PyPDF

## Resume Description

Developed a Retrieval-Augmented Generation (RAG) application for question-answering over enterprise documents. Implemented PDF ingestion, text chunking, vector embeddings, semantic search, and LLM-based response generation.