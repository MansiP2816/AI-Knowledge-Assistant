from openai import OpenAI
from src.pdf_reader import extract_text
from src.embeddings import create_chunks, create_embeddings, get_model
from src.search import build_index, search

PDF_FILE = "data/company_handbook.pdf"

text = extract_text(PDF_FILE)
chunks = create_chunks(text)

embeddings = create_embeddings(chunks)
index = build_index(embeddings)

model = get_model()

query = input("Ask a question: ")

query_embedding = model.encode([query])
results = search(index, query_embedding, 3)

context = "\n".join([chunks[i] for i in results])

client = OpenAI(api_key="YOUR_OPENAI_API_KEY")

prompt = f'''
Answer using only the context below.

Context:
{context}

Question:
{query}
'''

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role":"user","content":prompt}]
)

print("\nAnswer:\n")
print(response.choices[0].message.content)